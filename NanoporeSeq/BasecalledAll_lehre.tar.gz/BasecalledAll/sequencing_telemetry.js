[
    {
        "aggregation": "segment", 
        "analysis_id": "e72735bc-a9fe-4319-9e2d-e24858f1302b", 
        "basecall_1d": {
            "exit_status_dist": {
                "fail:qscore_filter": 334, 
                "pass": 666
            }, 
            "qscore_dist_temp": [
                {
                    "count": 1, 
                    "mean_qscore": 2.5
                }, 
                {
                    "count": 2, 
                    "mean_qscore": 3.5
                }, 
                {
                    "count": 3, 
                    "mean_qscore": 4.0
                }, 
                {
                    "count": 13, 
                    "mean_qscore": 4.5
                }, 
                {
                    "count": 36, 
                    "mean_qscore": 5.0
                }, 
                {
                    "count": 28, 
                    "mean_qscore": 5.5
                }, 
                {
                    "count": 24, 
                    "mean_qscore": 6.0
                }, 
                {
                    "count": 25, 
                    "mean_qscore": 6.5
                }, 
                {
                    "count": 43, 
                    "mean_qscore": 7.0
                }, 
                {
                    "count": 49, 
                    "mean_qscore": 7.5
                }, 
                {
                    "count": 58, 
                    "mean_qscore": 8.0
                }, 
                {
                    "count": 52, 
                    "mean_qscore": 8.5
                }, 
                {
                    "count": 69, 
                    "mean_qscore": 9.0
                }, 
                {
                    "count": 106, 
                    "mean_qscore": 9.5
                }, 
                {
                    "count": 140, 
                    "mean_qscore": 10.0
                }, 
                {
                    "count": 134, 
                    "mean_qscore": 10.5
                }, 
                {
                    "count": 103, 
                    "mean_qscore": 11.0
                }, 
                {
                    "count": 58, 
                    "mean_qscore": 11.5
                }, 
                {
                    "count": 33, 
                    "mean_qscore": 12.0
                }, 
                {
                    "count": 10, 
                    "mean_qscore": 12.5
                }, 
                {
                    "count": 8, 
                    "mean_qscore": 13.0
                }, 
                {
                    "count": 5, 
                    "mean_qscore": 13.5
                }
            ], 
            "qscore_sum_temp": {
                "count": 1000, 
                "mean": 9.477633476257324, 
                "sum": 9477.6337890625
            }, 
            "read_len_events_sum_temp": 5288477, 
            "seq_len_bases_dist_temp": [
                {
                    "count": 1000, 
                    "length": 0.0
                }
            ], 
            "seq_len_bases_sum_temp": 1000, 
            "seq_len_events_dist_temp": [
                {
                    "count": 103, 
                    "length": 0.0
                }, 
                {
                    "count": 102, 
                    "length": 1000.0
                }, 
                {
                    "count": 55, 
                    "length": 2000.0
                }, 
                {
                    "count": 49, 
                    "length": 3000.0
                }, 
                {
                    "count": 43, 
                    "length": 4000.0
                }, 
                {
                    "count": 67, 
                    "length": 5000.0
                }, 
                {
                    "count": 276, 
                    "length": 6000.0
                }, 
                {
                    "count": 250, 
                    "length": 7000.0
                }, 
                {
                    "count": 25, 
                    "length": 8000.0
                }, 
                {
                    "count": 14, 
                    "length": 9000.0
                }, 
                {
                    "count": 7, 
                    "length": 10000.0
                }, 
                {
                    "count": 2, 
                    "length": 11000.0
                }, 
                {
                    "count": 3, 
                    "length": 13000.0
                }, 
                {
                    "count": 3, 
                    "length": 14000.0
                }, 
                {
                    "count": 1, 
                    "length": 18000.0
                }
            ], 
            "speed_bases_per_second_dist_temp": [
                {
                    "count": 1000, 
                    "speed": 1.0
                }
            ], 
            "strand_median_pa": {
                "count": 1000, 
                "mean": 74.46405029296875, 
                "sum": 74464.046875
            }, 
            "strand_sd_pa": {
                "count": 1000, 
                "mean": 9.2243804931640625, 
                "sum": 9224.380859375
            }
        }, 
        "channel_count": 86, 
        "context_tags": {
            "barcoding_enabled": "0", 
            "experiment_duration_set": "1440", 
            "experiment_type": "genomic_dna", 
            "local_basecalling": "0", 
            "package": "bream4", 
            "package_version": "7.0.9", 
            "sample_frequency": "4000", 
            "sequencing_kit": "sqk-rbk004"
        }, 
        "latest_run_time": 556.8912353515625, 
        "levels_sums": {
            "count": 1000, 
            "mean": 204.08787536621094, 
            "open_pore_level_sum": 204087.875
        }, 
        "opts": {
            "beam_width": "32", 
            "calib_max_sequence_length": "3800", 
            "calib_min_coverage": "0.600000", 
            "calib_min_sequence_length": "3000", 
            "calib_reference": "lambda_3.6kb.fasta", 
            "chunk_size": "2000", 
            "chunks_per_caller": "10000", 
            "chunks_per_runner": "256", 
            "config": "/opt/ont/guppy/data/dna_r9.4.1_450bps_hac.cfg", 
            "flowcell": "FLO-FLG001", 
            "gpu_runners_per_device": "4", 
            "kit": "SQK-RBK004", 
            "min_qscore": "9.000000", 
            "model_file": "template_r9.4.1_450bps_hac.jsn", 
            "noisiest_section_scaling_max_size": "8000", 
            "overlap": "50", 
            "ping_segment_duration": "60", 
            "ping_url": "https://ping.oxfordnanoportal.com/basecall", 
            "qscore_offset": "-0.172100", 
            "qscore_scale": "0.935600", 
            "records_per_fastq": "4000", 
            "trim_min_events": "3", 
            "trim_strategy": "dna", 
            "trim_threshold": "2.500000"
        }, 
        "read_count": 1000, 
        "reads_per_channel_dist": [
            {
                "channel": 1, 
                "count": 5
            }, 
            {
                "channel": 2, 
                "count": 2
            }, 
            {
                "channel": 3, 
                "count": 11
            }, 
            {
                "channel": 5, 
                "count": 2
            }, 
            {
                "channel": 6, 
                "count": 3
            }, 
            {
                "channel": 7, 
                "count": 7
            }, 
            {
                "channel": 9, 
                "count": 4
            }, 
            {
                "channel": 10, 
                "count": 15
            }, 
            {
                "channel": 11, 
                "count": 5
            }, 
            {
                "channel": 12, 
                "count": 8
            }, 
            {
                "channel": 13, 
                "count": 5
            }, 
            {
                "channel": 15, 
                "count": 9
            }, 
            {
                "channel": 16, 
                "count": 4
            }, 
            {
                "channel": 18, 
                "count": 7
            }, 
            {
                "channel": 19, 
                "count": 9
            }, 
            {
                "channel": 21, 
                "count": 8
            }, 
            {
                "channel": 22, 
                "count": 8
            }, 
            {
                "channel": 23, 
                "count": 14
            }, 
            {
                "channel": 24, 
                "count": 12
            }, 
            {
                "channel": 25, 
                "count": 10
            }, 
            {
                "channel": 26, 
                "count": 8
            }, 
            {
                "channel": 27, 
                "count": 9
            }, 
            {
                "channel": 28, 
                "count": 8
            }, 
            {
                "channel": 29, 
                "count": 14
            }, 
            {
                "channel": 30, 
                "count": 12
            }, 
            {
                "channel": 31, 
                "count": 20
            }, 
            {
                "channel": 32, 
                "count": 16
            }, 
            {
                "channel": 33, 
                "count": 9
            }, 
            {
                "channel": 34, 
                "count": 12
            }, 
            {
                "channel": 35, 
                "count": 14
            }, 
            {
                "channel": 36, 
                "count": 11
            }, 
            {
                "channel": 37, 
                "count": 11
            }, 
            {
                "channel": 38, 
                "count": 5
            }, 
            {
                "channel": 40, 
                "count": 10
            }, 
            {
                "channel": 42, 
                "count": 19
            }, 
            {
                "channel": 43, 
                "count": 11
            }, 
            {
                "channel": 44, 
                "count": 11
            }, 
            {
                "channel": 45, 
                "count": 13
            }, 
            {
                "channel": 46, 
                "count": 19
            }, 
            {
                "channel": 47, 
                "count": 14
            }, 
            {
                "channel": 49, 
                "count": 16
            }, 
            {
                "channel": 50, 
                "count": 22
            }, 
            {
                "channel": 51, 
                "count": 8
            }, 
            {
                "channel": 54, 
                "count": 14
            }, 
            {
                "channel": 56, 
                "count": 10
            }, 
            {
                "channel": 57, 
                "count": 17
            }, 
            {
                "channel": 59, 
                "count": 20
            }, 
            {
                "channel": 63, 
                "count": 13
            }, 
            {
                "channel": 65, 
                "count": 12
            }, 
            {
                "channel": 66, 
                "count": 11
            }, 
            {
                "channel": 67, 
                "count": 14
            }, 
            {
                "channel": 70, 
                "count": 23
            }, 
            {
                "channel": 71, 
                "count": 8
            }, 
            {
                "channel": 72, 
                "count": 5
            }, 
            {
                "channel": 73, 
                "count": 15
            }, 
            {
                "channel": 74, 
                "count": 16
            }, 
            {
                "channel": 75, 
                "count": 14
            }, 
            {
                "channel": 77, 
                "count": 13
            }, 
            {
                "channel": 78, 
                "count": 11
            }, 
            {
                "channel": 79, 
                "count": 4
            }, 
            {
                "channel": 80, 
                "count": 11
            }, 
            {
                "channel": 81, 
                "count": 14
            }, 
            {
                "channel": 82, 
                "count": 11
            }, 
            {
                "channel": 83, 
                "count": 15
            }, 
            {
                "channel": 86, 
                "count": 3
            }, 
            {
                "channel": 90, 
                "count": 19
            }, 
            {
                "channel": 92, 
                "count": 14
            }, 
            {
                "channel": 94, 
                "count": 17
            }, 
            {
                "channel": 101, 
                "count": 5
            }, 
            {
                "channel": 102, 
                "count": 18
            }, 
            {
                "channel": 104, 
                "count": 16
            }, 
            {
                "channel": 105, 
                "count": 12
            }, 
            {
                "channel": 106, 
                "count": 13
            }, 
            {
                "channel": 107, 
                "count": 9
            }, 
            {
                "channel": 108, 
                "count": 13
            }, 
            {
                "channel": 109, 
                "count": 14
            }, 
            {
                "channel": 112, 
                "count": 13
            }, 
            {
                "channel": 114, 
                "count": 7
            }, 
            {
                "channel": 115, 
                "count": 15
            }, 
            {
                "channel": 116, 
                "count": 15
            }, 
            {
                "channel": 117, 
                "count": 10
            }, 
            {
                "channel": 119, 
                "count": 14
            }, 
            {
                "channel": 120, 
                "count": 13
            }, 
            {
                "channel": 121, 
                "count": 19
            }, 
            {
                "channel": 122, 
                "count": 14
            }, 
            {
                "channel": 123, 
                "count": 16
            }
        ], 
        "run_id": "c9ffe0f31e537612d2cbf4c0f7e050d9b0d928a0", 
        "segment_duration": 60, 
        "segment_number": 1, 
        "segment_type": "guppy-acquisition", 
        "software": {
            "analysis": "1d_basecalling", 
            "name": "guppy-basecalling", 
            "version": "6.3.7+532d626"
        }, 
        "tracking_id": {
            "asic_id": "17917800", 
            "asic_id_eeprom": "7719509", 
            "asic_temp": "38.214821", 
            "asic_version": "IA02D", 
            "auto_update": "0", 
            "auto_update_source": "https://mirror.oxfordnanoportal.com/software/MinKNOW/", 
            "bream_is_standard": "0", 
            "configuration_version": "5.0.8", 
            "device_id": "MN33612", 
            "device_type": "minion", 
            "distribution_status": "stable", 
            "distribution_version": "22.03.6", 
            "exp_script_name": "sequencing_MIN106_DNA:FLO-FLG001:SQK-RBK004", 
            "exp_script_purpose": "sequencing_run", 
            "exp_start_time": "2022-07-14T18:35:28.162888+02:00", 
            "flongle_adapter_id": "FA-06611", 
            "flow_cell_id": "ALT327", 
            "flow_cell_product_code": "FLO-FLG001", 
            "guppy_version": "6.0.7+c7819bc52", 
            "heatsink_temp": "37.945313", 
            "host_product_code": "unknown", 
            "host_product_serial_number": "", 
            "hostname": "DESKTOP-CTFRQHH", 
            "installation_type": "nc", 
            "local_firmware_file": "1", 
            "msg_id": "3c9cef68-8324-465c-bcc4-5c7dcc083664", 
            "operating_system": "Windows 10.0", 
            "protocol_group_id": "Probelauf_220714", 
            "protocol_run_id": "0830775f-494a-46c1-9ef7-4f8db6ec30e4", 
            "protocol_start_time": "2022-07-14T18:30:17.759886+02:00", 
            "protocols_version": "7.0.9", 
            "run_id": "c9ffe0f31e537612d2cbf4c0f7e050d9b0d928a0", 
            "sample_id": "pBR322", 
            "time_stamp": "2024-01-10T22:11:29Z", 
            "usb_config": "fx3_1.2.4#fpga_1.2.1#bulk#USB300", 
            "version": "5.0.0"
        }
    }, 
    {
        "aggregation": "cumulative", 
        "analysis_id": "e72735bc-a9fe-4319-9e2d-e24858f1302b", 
        "basecall_1d": {
            "exit_status_dist": {
                "fail:qscore_filter": 334, 
                "pass": 666
            }, 
            "qscore_dist_temp": [
                {
                    "count": 1, 
                    "mean_qscore": 2.5
                }, 
                {
                    "count": 2, 
                    "mean_qscore": 3.5
                }, 
                {
                    "count": 3, 
                    "mean_qscore": 4.0
                }, 
                {
                    "count": 13, 
                    "mean_qscore": 4.5
                }, 
                {
                    "count": 36, 
                    "mean_qscore": 5.0
                }, 
                {
                    "count": 28, 
                    "mean_qscore": 5.5
                }, 
                {
                    "count": 24, 
                    "mean_qscore": 6.0
                }, 
                {
                    "count": 25, 
                    "mean_qscore": 6.5
                }, 
                {
                    "count": 43, 
                    "mean_qscore": 7.0
                }, 
                {
                    "count": 49, 
                    "mean_qscore": 7.5
                }, 
                {
                    "count": 58, 
                    "mean_qscore": 8.0
                }, 
                {
                    "count": 52, 
                    "mean_qscore": 8.5
                }, 
                {
                    "count": 69, 
                    "mean_qscore": 9.0
                }, 
                {
                    "count": 106, 
                    "mean_qscore": 9.5
                }, 
                {
                    "count": 140, 
                    "mean_qscore": 10.0
                }, 
                {
                    "count": 134, 
                    "mean_qscore": 10.5
                }, 
                {
                    "count": 103, 
                    "mean_qscore": 11.0
                }, 
                {
                    "count": 58, 
                    "mean_qscore": 11.5
                }, 
                {
                    "count": 33, 
                    "mean_qscore": 12.0
                }, 
                {
                    "count": 10, 
                    "mean_qscore": 12.5
                }, 
                {
                    "count": 8, 
                    "mean_qscore": 13.0
                }, 
                {
                    "count": 5, 
                    "mean_qscore": 13.5
                }
            ], 
            "qscore_sum_temp": {
                "count": 1000, 
                "mean": 9.477633476257324, 
                "sum": 9477.6337890625
            }, 
            "read_len_events_sum_temp": 5288477, 
            "seq_len_bases_dist_temp": [
                {
                    "count": 1000, 
                    "length": 0.0
                }
            ], 
            "seq_len_bases_sum_temp": 1000, 
            "seq_len_events_dist_temp": [
                {
                    "count": 103, 
                    "length": 0.0
                }, 
                {
                    "count": 102, 
                    "length": 1000.0
                }, 
                {
                    "count": 55, 
                    "length": 2000.0
                }, 
                {
                    "count": 49, 
                    "length": 3000.0
                }, 
                {
                    "count": 43, 
                    "length": 4000.0
                }, 
                {
                    "count": 67, 
                    "length": 5000.0
                }, 
                {
                    "count": 276, 
                    "length": 6000.0
                }, 
                {
                    "count": 250, 
                    "length": 7000.0
                }, 
                {
                    "count": 25, 
                    "length": 8000.0
                }, 
                {
                    "count": 14, 
                    "length": 9000.0
                }, 
                {
                    "count": 7, 
                    "length": 10000.0
                }, 
                {
                    "count": 2, 
                    "length": 11000.0
                }, 
                {
                    "count": 3, 
                    "length": 13000.0
                }, 
                {
                    "count": 3, 
                    "length": 14000.0
                }, 
                {
                    "count": 1, 
                    "length": 18000.0
                }
            ], 
            "speed_bases_per_second_dist_temp": [
                {
                    "count": 1000, 
                    "speed": 1.0
                }
            ], 
            "strand_median_pa": {
                "count": 1000, 
                "mean": 74.46405029296875, 
                "sum": 74464.046875
            }, 
            "strand_sd_pa": {
                "count": 1000, 
                "mean": 9.2243804931640625, 
                "sum": 9224.380859375
            }
        }, 
        "channel_count": 86, 
        "context_tags": {
            "barcoding_enabled": "0", 
            "experiment_duration_set": "1440", 
            "experiment_type": "genomic_dna", 
            "local_basecalling": "0", 
            "package": "bream4", 
            "package_version": "7.0.9", 
            "sample_frequency": "4000", 
            "sequencing_kit": "sqk-rbk004"
        }, 
        "latest_run_time": 556.8912353515625, 
        "levels_sums": {
            "count": 1000, 
            "mean": 204.08787536621094, 
            "open_pore_level_sum": 204087.875
        }, 
        "opts": {
            "beam_width": "32", 
            "calib_max_sequence_length": "3800", 
            "calib_min_coverage": "0.600000", 
            "calib_min_sequence_length": "3000", 
            "calib_reference": "lambda_3.6kb.fasta", 
            "chunk_size": "2000", 
            "chunks_per_caller": "10000", 
            "chunks_per_runner": "256", 
            "config": "/opt/ont/guppy/data/dna_r9.4.1_450bps_hac.cfg", 
            "flowcell": "FLO-FLG001", 
            "gpu_runners_per_device": "4", 
            "kit": "SQK-RBK004", 
            "min_qscore": "9.000000", 
            "model_file": "template_r9.4.1_450bps_hac.jsn", 
            "noisiest_section_scaling_max_size": "8000", 
            "overlap": "50", 
            "ping_segment_duration": "60", 
            "ping_url": "https://ping.oxfordnanoportal.com/basecall", 
            "qscore_offset": "-0.172100", 
            "qscore_scale": "0.935600", 
            "records_per_fastq": "4000", 
            "trim_min_events": "3", 
            "trim_strategy": "dna", 
            "trim_threshold": "2.500000"
        }, 
        "read_count": 1000, 
        "reads_per_channel_dist": [
            {
                "channel": 1, 
                "count": 5
            }, 
            {
                "channel": 2, 
                "count": 2
            }, 
            {
                "channel": 3, 
                "count": 11
            }, 
            {
                "channel": 5, 
                "count": 2
            }, 
            {
                "channel": 6, 
                "count": 3
            }, 
            {
                "channel": 7, 
                "count": 7
            }, 
            {
                "channel": 9, 
                "count": 4
            }, 
            {
                "channel": 10, 
                "count": 15
            }, 
            {
                "channel": 11, 
                "count": 5
            }, 
            {
                "channel": 12, 
                "count": 8
            }, 
            {
                "channel": 13, 
                "count": 5
            }, 
            {
                "channel": 15, 
                "count": 9
            }, 
            {
                "channel": 16, 
                "count": 4
            }, 
            {
                "channel": 18, 
                "count": 7
            }, 
            {
                "channel": 19, 
                "count": 9
            }, 
            {
                "channel": 21, 
                "count": 8
            }, 
            {
                "channel": 22, 
                "count": 8
            }, 
            {
                "channel": 23, 
                "count": 14
            }, 
            {
                "channel": 24, 
                "count": 12
            }, 
            {
                "channel": 25, 
                "count": 10
            }, 
            {
                "channel": 26, 
                "count": 8
            }, 
            {
                "channel": 27, 
                "count": 9
            }, 
            {
                "channel": 28, 
                "count": 8
            }, 
            {
                "channel": 29, 
                "count": 14
            }, 
            {
                "channel": 30, 
                "count": 12
            }, 
            {
                "channel": 31, 
                "count": 20
            }, 
            {
                "channel": 32, 
                "count": 16
            }, 
            {
                "channel": 33, 
                "count": 9
            }, 
            {
                "channel": 34, 
                "count": 12
            }, 
            {
                "channel": 35, 
                "count": 14
            }, 
            {
                "channel": 36, 
                "count": 11
            }, 
            {
                "channel": 37, 
                "count": 11
            }, 
            {
                "channel": 38, 
                "count": 5
            }, 
            {
                "channel": 40, 
                "count": 10
            }, 
            {
                "channel": 42, 
                "count": 19
            }, 
            {
                "channel": 43, 
                "count": 11
            }, 
            {
                "channel": 44, 
                "count": 11
            }, 
            {
                "channel": 45, 
                "count": 13
            }, 
            {
                "channel": 46, 
                "count": 19
            }, 
            {
                "channel": 47, 
                "count": 14
            }, 
            {
                "channel": 49, 
                "count": 16
            }, 
            {
                "channel": 50, 
                "count": 22
            }, 
            {
                "channel": 51, 
                "count": 8
            }, 
            {
                "channel": 54, 
                "count": 14
            }, 
            {
                "channel": 56, 
                "count": 10
            }, 
            {
                "channel": 57, 
                "count": 17
            }, 
            {
                "channel": 59, 
                "count": 20
            }, 
            {
                "channel": 63, 
                "count": 13
            }, 
            {
                "channel": 65, 
                "count": 12
            }, 
            {
                "channel": 66, 
                "count": 11
            }, 
            {
                "channel": 67, 
                "count": 14
            }, 
            {
                "channel": 70, 
                "count": 23
            }, 
            {
                "channel": 71, 
                "count": 8
            }, 
            {
                "channel": 72, 
                "count": 5
            }, 
            {
                "channel": 73, 
                "count": 15
            }, 
            {
                "channel": 74, 
                "count": 16
            }, 
            {
                "channel": 75, 
                "count": 14
            }, 
            {
                "channel": 77, 
                "count": 13
            }, 
            {
                "channel": 78, 
                "count": 11
            }, 
            {
                "channel": 79, 
                "count": 4
            }, 
            {
                "channel": 80, 
                "count": 11
            }, 
            {
                "channel": 81, 
                "count": 14
            }, 
            {
                "channel": 82, 
                "count": 11
            }, 
            {
                "channel": 83, 
                "count": 15
            }, 
            {
                "channel": 86, 
                "count": 3
            }, 
            {
                "channel": 90, 
                "count": 19
            }, 
            {
                "channel": 92, 
                "count": 14
            }, 
            {
                "channel": 94, 
                "count": 17
            }, 
            {
                "channel": 101, 
                "count": 5
            }, 
            {
                "channel": 102, 
                "count": 18
            }, 
            {
                "channel": 104, 
                "count": 16
            }, 
            {
                "channel": 105, 
                "count": 12
            }, 
            {
                "channel": 106, 
                "count": 13
            }, 
            {
                "channel": 107, 
                "count": 9
            }, 
            {
                "channel": 108, 
                "count": 13
            }, 
            {
                "channel": 109, 
                "count": 14
            }, 
            {
                "channel": 112, 
                "count": 13
            }, 
            {
                "channel": 114, 
                "count": 7
            }, 
            {
                "channel": 115, 
                "count": 15
            }, 
            {
                "channel": 116, 
                "count": 15
            }, 
            {
                "channel": 117, 
                "count": 10
            }, 
            {
                "channel": 119, 
                "count": 14
            }, 
            {
                "channel": 120, 
                "count": 13
            }, 
            {
                "channel": 121, 
                "count": 19
            }, 
            {
                "channel": 122, 
                "count": 14
            }, 
            {
                "channel": 123, 
                "count": 16
            }
        ], 
        "run_id": "c9ffe0f31e537612d2cbf4c0f7e050d9b0d928a0", 
        "segment_duration": 60, 
        "segment_number": 1, 
        "segment_type": "guppy-acquisition", 
        "software": {
            "analysis": "1d_basecalling", 
            "name": "guppy-basecalling", 
            "version": "6.3.7+532d626"
        }, 
        "tracking_id": {
            "asic_id": "17917800", 
            "asic_id_eeprom": "7719509", 
            "asic_temp": "38.214821", 
            "asic_version": "IA02D", 
            "auto_update": "0", 
            "auto_update_source": "https://mirror.oxfordnanoportal.com/software/MinKNOW/", 
            "bream_is_standard": "0", 
            "configuration_version": "5.0.8", 
            "device_id": "MN33612", 
            "device_type": "minion", 
            "distribution_status": "stable", 
            "distribution_version": "22.03.6", 
            "exp_script_name": "sequencing_MIN106_DNA:FLO-FLG001:SQK-RBK004", 
            "exp_script_purpose": "sequencing_run", 
            "exp_start_time": "2022-07-14T18:35:28.162888+02:00", 
            "flongle_adapter_id": "FA-06611", 
            "flow_cell_id": "ALT327", 
            "flow_cell_product_code": "FLO-FLG001", 
            "guppy_version": "6.0.7+c7819bc52", 
            "heatsink_temp": "37.945313", 
            "host_product_code": "unknown", 
            "host_product_serial_number": "", 
            "hostname": "DESKTOP-CTFRQHH", 
            "installation_type": "nc", 
            "local_firmware_file": "1", 
            "msg_id": "f0994a5b-5db0-4bf4-b003-b278c749c711", 
            "operating_system": "Windows 10.0", 
            "protocol_group_id": "Probelauf_220714", 
            "protocol_run_id": "0830775f-494a-46c1-9ef7-4f8db6ec30e4", 
            "protocol_start_time": "2022-07-14T18:30:17.759886+02:00", 
            "protocols_version": "7.0.9", 
            "run_id": "c9ffe0f31e537612d2cbf4c0f7e050d9b0d928a0", 
            "sample_id": "pBR322", 
            "time_stamp": "2024-01-10T22:11:29Z", 
            "usb_config": "fx3_1.2.4#fpga_1.2.1#bulk#USB300", 
            "version": "5.0.0"
        }
    }
]